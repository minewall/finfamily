# Haile Brand Kit - Índice de Arquivos

## 📁 Estrutura do Kit

```
haile-brand-kit/
├── 📄 INDEX.md (este arquivo)
├── 🚀 QUICK-START.md
├── 📖 README-BRAND-KIT.md
├── 💻 haile-code-snippets.md
│
├── 🎨 Logos & Símbolos
│   ├── haile-logo-wordmark.svg
│   ├── haile-symbol-flow-mark.svg (⭐ recomendado)
│   ├── haile-symbol-h-flow.svg
│   └── haile-symbol-dot-circle.svg
│
├── 🎯 Design Tokens
│   ├── haile-tokens.json
│   ├── haile-tokens.css
│   └── haile-tokens.tailwind.ts
│
└── ⚙️ Configuração
    └── haile-manifest.json
```

## 🎯 Por Onde Começar?

### 1️⃣ Primeiro Contato
👉 **QUICK-START.md** - Comece aqui! Setup em 5 minutos.

### 2️⃣ Implementação
👉 **haile-code-snippets.md** - Copie e cole componentes prontos.

### 3️⃣ Referência Completa
👉 **README-BRAND-KIT.md** - Guia completo quando precisar de detalhes.

## 📦 Arquivos por Uso

### Para Designers (Figma/Sketch)
- `haile-tokens.json` → Importe no Tokens Studio
- `haile-symbol-flow-mark.svg` → Símbolo principal
- `haile-logo-wordmark.svg` → Wordmark completo

### Para Desenvolvedores Web
- `haile-tokens.css` → CSS Variables prontas
- `haile-tokens.tailwind.ts` → Config Tailwind
- `haile-code-snippets.md` → Componentes React/CSS
- `haile-manifest.json` → PWA setup

### Para Marketing
- `haile-logo-wordmark.svg` → Logo para materiais
- `README-BRAND-KIT.md` → Diretrizes de marca (cores, tom de voz)
- `haile-symbol-flow-mark.svg` → Favicon/ícone redes sociais

## 🎨 Cores Rápidas

```
Primária:     #7367F0 (Violeta Haile)
Secundária:   #06B6D4 (Teal AI)
Accent:       #10B981 (Verde Prosperidade)
Night:        #0B1020 (Quase-preto)
Cloud:        #F8FAFC (Quase-branco)
Alert:        #C92764 (Rosa Alert)
```

## 📐 Medidas Essenciais

```
Border Radius:  16px (padrão cards)
Padding Card:   24px
Gap Padrão:     16px
Sombra Card:    0 4px 12px rgba(11, 16, 32, 0.12)
Animação:       200ms cubic-bezier(0, 0, 0.2, 1)
```

## 🔤 Tipografia

```
Fonte:          DM Sans
Weights:        400 (Regular), 500 (Medium*), 600 (Semibold), 700 (Bold)
Base Size:      16px
Line Height:    1.5

*Sempre use Medium (500) ou superior para valores monetários
```

## ✅ Checklist de Implementação

```
□ Baixar arquivos necessários
□ Importar fonte DM Sans
□ Configurar tokens de cores
□ Adicionar logo/favicon
□ Aplicar border radius padrão (16px)
□ Configurar sombras
□ Adicionar tabular-nums em valores monetários
□ Testar contraste de cores
□ Validar animações (150-200ms)
□ Revisar tom de voz em textos
```

## 📊 Estatísticas do Kit

- **Total de arquivos**: 11
- **Tamanho total**: ~25KB (comprimido)
- **Cores únicas**: 9 + variações
- **Símbolos**: 3 opções + wordmark
- **Formatos**: SVG, JSON, CSS, TypeScript, Markdown
- **Plataformas**: Web, Mobile, Figma, PWA

## 🆘 Ajuda Rápida

| Preciso de... | Arquivo |
|---------------|---------|
| Logo para site | `haile-logo-wordmark.svg` |
| Favicon | `haile-symbol-flow-mark.svg` |
| Cores no CSS | `haile-tokens.css` |
| Cores no Tailwind | `haile-tokens.tailwind.ts` |
| Cores no Figma | `haile-tokens.json` |
| Componentes prontos | `haile-code-snippets.md` |
| Setup rápido | `QUICK-START.md` |
| Referência completa | `README-BRAND-KIT.md` |

## 🌐 Links Úteis

- **Fonte DM Sans**: https://fonts.google.com/specimen/DM+Sans
- **Lucide Icons**: https://lucide.dev
- **Tokens Studio (Figma)**: https://tokens.studio
- **Tailwind CSS**: https://tailwindcss.com

## 📝 Notas de Versão

**v1.0.0** - 2026-05-18
- ✨ Lançamento inicial do Haile Brand Kit
- 🎨 Sistema completo de cores (9 cores + variações)
- 📐 Design tokens em 3 formatos (JSON, CSS, TS)
- 🖼️ 4 assets visuais (1 wordmark + 3 símbolos)
- 📚 3 guias (Quick Start, Snippets, README)
- ⚙️ PWA manifest configurado

---

**Haile Brand Identity v1.0.0**  
Sistema de Identidade Visual 2026  
🇧🇷 Brasileiro com calibre global
