# Haile Brand Kit - Quick Start

Guia rápido para começar a usar o Haile Brand Kit em 5 minutos.

## 🚀 Setup Rápido

### 1. Logo e Favicon

**Para Web:**
```html
<!-- Favicon -->
<link rel="icon" type="image/svg+xml" href="/haile-symbol-flow-mark.svg">

<!-- Apple Touch Icon (criar PNG 180x180) -->
<link rel="apple-touch-icon" href="/haile-icon-180.png">
```

**Para App Mobile:**
Use `haile-symbol-flow-mark.svg` como base e exporte em:
- 16x16, 32x32 (favicon)
- 64x64, 128x128, 256x256, 512x512 (app icons)

### 2. Cores (CSS)

**Opção A - Importar CSS:**
```css
@import url('/haile-tokens.css');

/* Usar variáveis */
.button {
  background: var(--haile-violet);
  color: white;
  border-radius: var(--radius-lg);
  padding: var(--spacing-md) var(--spacing-xl);
}
```

**Opção B - Tailwind:**
```javascript
// tailwind.config.js
import haileTokens from './public/haile-tokens.tailwind'

export default {
  theme: {
    extend: haileTokens
  }
}
```

```jsx
// Usar em componentes
<button className="bg-haile-violet text-white rounded-haile-lg px-haile-xl">
  Começar
</button>
```

### 3. Tipografia

**Importar fonte:**
```css
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap');

body {
  font-family: 'DM Sans', -apple-system, sans-serif;
}
```

**Para valores monetários:**
```css
.monetary-value {
  font-family: 'DM Sans', monospace;
  font-weight: 500; /* Sempre Medium ou superior */
  font-variant-numeric: tabular-nums; /* Números alinhados */
}
```

## 🎨 Cores Principais (Copiar/Colar)

```css
/* Primária */
--violet: #7367F0;

/* Secundária */
--teal: #06B6D4;

/* Accent */
--prosperity: #10B981;

/* Neutros */
--night: #0B1020;
--cloud: #F8FAFC;

/* Alert */
--alert: #C92764;
```

## 📱 Componentes Prontos

### Botão Primário
```css
.btn-primary {
  background: #7367F0;
  color: white;
  padding: 12px 24px;
  border-radius: 16px;
  font-weight: 500;
  transition: all 200ms cubic-bezier(0, 0, 0.2, 1);
}

.btn-primary:hover {
  box-shadow: 0 4px 12px rgba(11, 16, 32, 0.12);
  transform: translateY(-1px);
}
```

### Card
```css
.card {
  background: white;
  padding: 24px;
  border-radius: 16px;
  border: 1px solid rgba(0, 0, 0, 0.05);
}

.card:hover {
  box-shadow: 0 4px 12px rgba(11, 16, 32, 0.12);
}
```

### Valor Monetário
```jsx
<div className="monetary">
  <span className="text-5xl font-semibold text-prosperity tabular-nums">
    R$ 8.450,32
  </span>
</div>
```

## 🎯 Checklist Essencial

- [ ] Logo/favicon instalado
- [ ] Fonte DM Sans importada
- [ ] Cores principais definidas
- [ ] Border radius de 16px como padrão para cards
- [ ] Sombras aplicadas em hover states
- [ ] `tabular-nums` em valores monetários
- [ ] Peso Medium (500) ou superior em números

## 📚 Próximos Passos

1. Consulte `README-BRAND-KIT.md` para guia completo
2. Veja os mockups na seção "Aplicações" do guidelines app
3. Use os design tokens JSON no Figma (Tokens Studio plugin)

## 💡 Dicas Rápidas

✅ **Faça:**
- Use o símbolo Flow Mark para ícones
- Aplique `tabular-nums` em valores monetários
- Mantenha raios de borda consistentes (12-16px)
- Use animações de 150-200ms

❌ **Não faça:**
- Não use font-weight Regular (400) em valores monetários
- Não misture mais de 3 cores primárias na mesma tela
- Não use animações mais lentas que 300ms
- Não use raios menores que 8px

---

**Haile Brand Identity v1.0.0**
