# Haile - Code Snippets

Snippets de código prontos para copiar e colar no seu projeto.

## 🎨 Setup Inicial

### HTML Head (Completo)
```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <!-- Haile Branding -->
  <title>Haile - Seu coach financeiro pessoal</title>
  <meta name="description" content="App brasileiro de gestão financeira familiar com AI Coach">
  <meta name="theme-color" content="#7367F0">
  
  <!-- Favicons -->
  <link rel="icon" type="image/svg+xml" href="/haile-symbol-flow-mark.svg">
  <link rel="apple-touch-icon" href="/haile-icon-180.png">
  
  <!-- Manifest PWA -->
  <link rel="manifest" href="/haile-manifest.json">
  
  <!-- Fontes -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
  <!-- Seu app -->
</body>
</html>
```

## 💅 Componentes CSS

### Botões

```css
/* Primário */
.btn-primary {
  background: #7367F0;
  color: white;
  padding: 12px 24px;
  border-radius: 16px;
  font-weight: 500;
  font-size: 16px;
  border: none;
  cursor: pointer;
  transition: all 200ms cubic-bezier(0, 0, 0.2, 1);
}

.btn-primary:hover {
  box-shadow: 0 4px 12px rgba(115, 103, 240, 0.3);
  transform: translateY(-1px);
}

.btn-primary:active {
  transform: translateY(0);
}

/* Secundário */
.btn-secondary {
  background: #06B6D4;
  color: white;
  padding: 12px 24px;
  border-radius: 16px;
  font-weight: 500;
  font-size: 16px;
  border: none;
  cursor: pointer;
  transition: all 200ms cubic-bezier(0, 0, 0.2, 1);
}

/* Outline */
.btn-outline {
  background: transparent;
  color: #7367F0;
  padding: 12px 24px;
  border-radius: 16px;
  font-weight: 500;
  font-size: 16px;
  border: 1px solid #7367F0;
  cursor: pointer;
  transition: all 200ms cubic-bezier(0, 0, 0.2, 1);
}

.btn-outline:hover {
  background: #7367F0;
  color: white;
}
```

### Cards

```css
/* Card Padrão */
.card {
  background: white;
  padding: 24px;
  border-radius: 16px;
  border: 1px solid rgba(0, 0, 0, 0.05);
  transition: all 200ms cubic-bezier(0, 0, 0.2, 1);
}

.card:hover {
  box-shadow: 0 4px 12px rgba(11, 16, 32, 0.12);
  transform: translateY(-2px);
}

/* Card com Gradiente */
.card-gradient {
  background: linear-gradient(135deg, #7367F0 0%, #5B4FCE 100%);
  color: white;
  padding: 32px;
  border-radius: 24px;
  position: relative;
  overflow: hidden;
}

.card-gradient::before {
  content: '';
  position: absolute;
  top: 0;
  right: 0;
  width: 256px;
  height: 256px;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 50%;
  filter: blur(60px);
}

/* Card KPI */
.card-kpi {
  background: white;
  padding: 24px;
  border-radius: 16px;
  border: 1px solid rgba(0, 0, 0, 0.05);
}

.card-kpi-value {
  font-size: 48px;
  font-weight: 600;
  color: #0B1020;
  font-variant-numeric: tabular-nums;
  line-height: 1.2;
}

.card-kpi-label {
  font-size: 14px;
  color: #64748B;
  margin-bottom: 8px;
}
```

### Inputs

```css
.input {
  width: 100%;
  padding: 12px 16px;
  border: 1px solid rgba(0, 0, 0, 0.1);
  border-radius: 12px;
  font-size: 16px;
  font-family: 'DM Sans', sans-serif;
  transition: all 150ms cubic-bezier(0, 0, 0.2, 1);
  background: white;
}

.input:focus {
  outline: none;
  border-color: #7367F0;
  box-shadow: 0 0 0 3px rgba(115, 103, 240, 0.1);
}

.input::placeholder {
  color: #94A3B8;
}
```

### Badges

```css
/* Badge IA */
.badge-ai {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  background: rgba(6, 182, 212, 0.1);
  color: #06B6D4;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 500;
}

/* Badge Positivo */
.badge-positive {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  background: rgba(16, 185, 129, 0.1);
  color: #10B981;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 500;
}

/* Badge Alert */
.badge-alert {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  background: rgba(201, 39, 100, 0.1);
  color: #C92764;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 500;
}
```

## ⚛️ React Components

### Botão Primário

```jsx
function Button({ children, variant = 'primary', onClick }) {
  const styles = {
    primary: 'bg-[#7367F0] text-white hover:shadow-lg',
    secondary: 'bg-[#06B6D4] text-white hover:shadow-lg',
    outline: 'bg-transparent text-[#7367F0] border border-[#7367F0] hover:bg-[#7367F0] hover:text-white'
  };

  return (
    <button
      onClick={onClick}
      className={`px-6 py-3 rounded-2xl font-medium transition-all duration-200 ${styles[variant]}`}
    >
      {children}
    </button>
  );
}
```

### Card KPI

```jsx
function KPICard({ label, value, trend, icon: Icon }) {
  return (
    <div className="bg-white p-6 rounded-2xl border border-black/5 hover:shadow-md transition-shadow">
      <div className="flex items-center gap-3 mb-4">
        {Icon && (
          <div className="w-12 h-12 bg-[#7367F0]/10 rounded-xl flex items-center justify-center">
            <Icon className="w-6 h-6 text-[#7367F0]" />
          </div>
        )}
        <p className="text-sm text-[#64748B]">{label}</p>
      </div>
      <div className="text-4xl font-semibold text-[#0B1020] tabular-nums mb-2">
        {value}
      </div>
      {trend && (
        <p className="text-sm text-[#10B981] flex items-center gap-1">
          <span>↑</span> {trend}
        </p>
      )}
    </div>
  );
}

// Uso:
<KPICard
  label="Poder de Escolha"
  value="R$ 8.450,32"
  trend="+R$ 320 vs. mês passado"
  icon={Zap}
/>
```

### Badge

```jsx
function Badge({ children, variant = 'default' }) {
  const styles = {
    default: 'bg-[#7367F0]/10 text-[#7367F0]',
    ai: 'bg-[#06B6D4]/10 text-[#06B6D4]',
    positive: 'bg-[#10B981]/10 text-[#10B981]',
    alert: 'bg-[#C92764]/10 text-[#C92764]'
  };

  return (
    <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-lg text-xs font-medium ${styles[variant]}`}>
      {children}
    </span>
  );
}
```

## 💰 Formatação de Valores Monetários

### JavaScript
```javascript
// Formatar valor monetário brasileiro
function formatMoney(value) {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value);
}

// Uso:
formatMoney(8450.32); // "R$ 8.450,32"
```

### React Hook
```jsx
function useMoney() {
  const format = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  return { format };
}

// Uso:
function Component() {
  const { format } = useMoney();
  return <span className="tabular-nums">{format(8450.32)}</span>;
}
```

## 🎬 Animações

### Fade In
```css
@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

.fade-in {
  animation: fadeIn 200ms cubic-bezier(0, 0, 0.2, 1);
}
```

### Slide Up
```css
@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.slide-up {
  animation: slideUp 200ms cubic-bezier(0, 0, 0.2, 1);
}
```

### Scale In
```css
@keyframes scaleIn {
  from {
    opacity: 0;
    transform: scale(0.95);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

.scale-in {
  animation: scaleIn 150ms cubic-bezier(0, 0, 0.2, 1);
}
```

## 🎨 Glassmorphism

```css
.glass {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(16px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 16px;
}

.glass-dark {
  background: rgba(11, 16, 32, 0.1);
  backdrop-filter: blur(16px);
  border: 1px solid rgba(11, 16, 32, 0.2);
  border-radius: 16px;
}
```

## 📱 Loading States

```jsx
function LoadingSkeleton() {
  return (
    <div className="animate-pulse">
      <div className="h-8 bg-[#F8FAFC] rounded-xl mb-4" />
      <div className="h-4 bg-[#F8FAFC] rounded-lg w-3/4 mb-2" />
      <div className="h-4 bg-[#F8FAFC] rounded-lg w-1/2" />
    </div>
  );
}
```

```css
@keyframes pulse {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.5;
  }
}

.animate-pulse {
  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}
```

---

**Dica:** Todos os snippets usam a paleta de cores, espaçamento e animações do Haile Brand Kit.
