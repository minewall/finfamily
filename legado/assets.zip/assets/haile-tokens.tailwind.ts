/**
 * Haile Design Tokens - Tailwind Config
 * Sistema de Identidade Visual 2026
 *
 * Importe este arquivo no seu tailwind.config.js:
 * const haileTokens = require('./haile-tokens.tailwind')
 *
 * module.exports = {
 *   theme: {
 *     extend: haileTokens
 *   }
 * }
 */

export const haileTokens = {
  colors: {
    haile: {
      violet: {
        light: '#9990FF',
        DEFAULT: '#7367F0',
        dark: '#5B4FCE',
      },
      teal: {
        light: '#22D3EE',
        DEFAULT: '#06B6D4',
        dark: '#0891B2',
      },
      prosperity: {
        light: '#34D399',
        DEFAULT: '#10B981',
        dark: '#059669',
      },
      night: '#0B1020',
      slate: '#334155',
      mist: '#94A3B8',
      cloud: '#F8FAFC',
      alert: '#C92764',
    },
  },
  spacing: {
    'haile-xs': '4px',
    'haile-sm': '8px',
    'haile-md': '12px',
    'haile-lg': '16px',
    'haile-xl': '24px',
    'haile-2xl': '32px',
    'haile-3xl': '48px',
  },
  borderRadius: {
    'haile-sm': '8px',
    'haile-md': '12px',
    'haile-lg': '16px',
    'haile-xl': '24px',
  },
  boxShadow: {
    'haile-sm': '0 1px 3px rgba(11, 16, 32, 0.08)',
    'haile-md': '0 4px 12px rgba(11, 16, 32, 0.12)',
    'haile-lg': '0 12px 40px rgba(11, 16, 32, 0.16)',
  },
  fontFamily: {
    haile: ['DM Sans', '-apple-system', 'system-ui', 'sans-serif'],
  },
  fontWeight: {
    'haile-regular': '400',
    'haile-medium': '500',
    'haile-semibold': '600',
    'haile-bold': '700',
  },
  transitionDuration: {
    'haile-fast': '150ms',
    'haile-normal': '200ms',
    'haile-slow': '300ms',
  },
  transitionTimingFunction: {
    'haile-default': 'cubic-bezier(0.4, 0, 0.2, 1)',
    'haile-in': 'cubic-bezier(0.4, 0, 1, 1)',
    'haile-out': 'cubic-bezier(0, 0, 0.2, 1)',
  },
};

export default haileTokens;
